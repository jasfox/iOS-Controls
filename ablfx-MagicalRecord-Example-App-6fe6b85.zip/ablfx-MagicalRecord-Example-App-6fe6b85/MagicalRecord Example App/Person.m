//
//  Person.m
//  MagicalRecord Example App
//
//  Created by Alexander Blunck on 05.03.12.
//  Copyright (c) 2012 Ablfx. All rights reserved.
//

#import "Person.h"


@implementation Person

@dynamic name;
@dynamic age;

@end
