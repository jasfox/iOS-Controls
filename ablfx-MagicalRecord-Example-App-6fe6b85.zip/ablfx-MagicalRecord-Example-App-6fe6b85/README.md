MagicalRecord Example App
=============


INFO
-------------
This iOS Appication is part of a tutorial I wrote on my Blog to explain the use of the [MagicalRecord](https://github.com/magicalpanda) Library by MagicalPanda


Tutorial
------
[Ablfx.com - Using MagicalRecord + CoreData](http://ablfx.com/blog/2012/03/using-coredata-magicalrecord/)
