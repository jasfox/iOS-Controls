//
//  main.m
//  iOSLibraries
//
//  Created by jeremy Templier on 27/03/12.
//  Copyright (c) 2012 particulier. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ILAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([ILAppDelegate class]));
    }
}
