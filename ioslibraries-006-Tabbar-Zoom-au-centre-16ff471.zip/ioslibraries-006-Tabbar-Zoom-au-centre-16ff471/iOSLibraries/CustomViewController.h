//
//  CustomViewController.h
//  iOSLibraries
//
//  Created by jeremy Templier on 27/03/12.
//  Copyright (c) 2012 particulier. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomViewController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *customLabel;
@end
